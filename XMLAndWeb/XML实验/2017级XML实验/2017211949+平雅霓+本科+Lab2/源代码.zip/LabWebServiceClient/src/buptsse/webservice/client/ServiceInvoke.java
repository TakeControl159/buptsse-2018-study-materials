package buptsse.webservice.client;
import java.net.*;
import javax.xml.*;
import javax.xml.namespace.QName;
import javax.xml.ws.Service;

import buptsse.webservice.StringOperation;

public class ServiceInvoke {

	public static void main(String[] args)throws MalformedURLException {
		URL url = new URL("http://localhost:9090/stringoperation?wsdl");
		QName 
		serviceName = new QName("http://webservice.buptsse/","StringOperationService");
		Service service=Service.create(url,serviceName);
		StringOperation stringOP = service.getPort(new QName("http://webservice.buptsse/","StringOperationPort"),StringOperation.class);
		String addStr = stringOP.addString("Hello ! ", "pyn");
		boolean compareStr1 = stringOP.compareStr("Hello world!", "Hello world!");
		boolean compareStr2 = stringOP.compareStr("Elvira", "Pingyani");
		System.out.println("Result of addstring('Hello ! ','pyn') is: "+addStr);
		System.out.println("Result of compareStr('Hello world!','Hello world!') is: "+compareStr1);
		System.out.println("Result of compareStr('Elvira','Pingyani') is: "+compareStr2);
	}

}

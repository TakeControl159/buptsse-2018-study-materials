@javax.xml.bind.annotation.XmlSchema(namespace = "http://buptsse/")
package buptsse.client;

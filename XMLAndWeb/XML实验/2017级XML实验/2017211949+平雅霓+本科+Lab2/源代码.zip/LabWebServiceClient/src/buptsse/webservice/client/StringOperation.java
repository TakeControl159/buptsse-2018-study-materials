package buptsse.webservice.client;

import javax.jws.WebMethod;
import javax.jws.WebService;


@WebService
public class StringOperation {
	public boolean CompareStr(String aStr, String bStr){
		if(aStr.equals(bStr))
			return true;
		else return false;
	}
	public String AddString(String aStr, String bStr){
		return aStr.concat(bStr);
	}
	@WebMethod(exclude=true)
	public void doublekill(){
		
	}	
}

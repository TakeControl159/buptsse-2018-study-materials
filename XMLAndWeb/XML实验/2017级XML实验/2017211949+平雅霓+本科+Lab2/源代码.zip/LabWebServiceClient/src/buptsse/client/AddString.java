
package buptsse.client;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;

/**
 * <p>
 * Java class for AddString complex type.
 * 
 * <p>
 * The following schema fragment specifies the expected content contained within
 * this class.
 * 
 * <pre>
 * &lt;complexType name="AddString">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="aStr" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="bStr" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "AddString", propOrder = { "aStr", "bStr" })
public class AddString {

	protected String aStr;
	protected String bStr;

	/**
	 * Gets the value of the aStr property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getAStr() {
		return aStr;
	}

	/**
	 * Sets the value of the aStr property.
	 * 
	 * @param value
	 *            allowed object is {@link String }
	 * 
	 */
	public void setAStr(String value) {
		this.aStr = value;
	}

	/**
	 * Gets the value of the bStr property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getBStr() {
		return bStr;
	}

	/**
	 * Sets the value of the bStr property.
	 * 
	 * @param value
	 *            allowed object is {@link String }
	 * 
	 */
	public void setBStr(String value) {
		this.bStr = value;
	}

}

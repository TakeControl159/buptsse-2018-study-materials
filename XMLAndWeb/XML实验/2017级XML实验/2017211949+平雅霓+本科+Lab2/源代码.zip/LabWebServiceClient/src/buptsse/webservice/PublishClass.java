package buptsse.webservice;

import javax.xml.ws.Endpoint;

public class PublishClass {
	public static void main(String args[]){
		Endpoint.publish("http://localhost:9090/stringoperation",new StringOperation());
	}	
}

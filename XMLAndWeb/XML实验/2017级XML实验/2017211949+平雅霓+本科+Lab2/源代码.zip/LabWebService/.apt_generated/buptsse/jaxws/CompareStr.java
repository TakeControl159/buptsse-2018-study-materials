
package buptsse.jaxws;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

@XmlRootElement(name = "CompareStr", namespace = "http://buptsse/")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "CompareStr", namespace = "http://buptsse/", propOrder = {
    "aStr",
    "bStr"
})
public class CompareStr {

    @XmlElement(name = "aStr", namespace = "")
    private String aStr;
    @XmlElement(name = "bStr", namespace = "")
    private String bStr;

    /**
     * 
     * @return
     *     returns String
     */
    public String getAStr() {
        return this.aStr;
    }

    /**
     * 
     * @param aStr
     *     the value for the aStr property
     */
    public void setAStr(String aStr) {
        this.aStr = aStr;
    }

    /**
     * 
     * @return
     *     returns String
     */
    public String getBStr() {
        return this.bStr;
    }

    /**
     * 
     * @param bStr
     *     the value for the bStr property
     */
    public void setBStr(String bStr) {
        this.bStr = bStr;
    }

}

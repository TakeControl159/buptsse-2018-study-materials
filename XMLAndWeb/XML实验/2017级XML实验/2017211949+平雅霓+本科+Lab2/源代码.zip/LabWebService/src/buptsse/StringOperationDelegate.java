package buptsse;

import javax.jws.WebParam;

@javax.jws.WebService(targetNamespace = "http://buptsse/", serviceName = "StringOperationService", portName = "StringOperationPort", wsdlLocation = "WEB-INF/wsdl/StringOperationService.wsdl")

public class StringOperationDelegate {

	buptsse.StringOperation stringOperation = new buptsse.StringOperation();

	public Boolean CompareStr(@WebParam(name = "aStr") String aStr, @WebParam(name = "bStr") String bStr) {
		return stringOperation.CompareStr(aStr, bStr);
	}

	public String AddString(@WebParam(name = "aStr") String aStr, @WebParam(name = "bStr") String bStr) {
		return stringOperation.AddString(aStr, bStr);
	}

}
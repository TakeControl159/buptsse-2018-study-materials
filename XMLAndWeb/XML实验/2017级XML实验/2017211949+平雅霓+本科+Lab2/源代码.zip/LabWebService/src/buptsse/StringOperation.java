package buptsse;

public class StringOperation {
	public Boolean CompareStr(String aStr, String bStr){
		if(aStr.equals(bStr))
			return true;
		else return false;
	}
	public String AddString(String aStr, String bStr){
		return aStr.concat(bStr);
	}
}

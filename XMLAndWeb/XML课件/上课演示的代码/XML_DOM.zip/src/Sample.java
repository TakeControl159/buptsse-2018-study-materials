import javax.xml.parsers.*; // for both SAX and DOM
import org.xml.sax.*;
import org.xml.sax.helpers.*;

// For simplicity, we let the operating system handle exceptions
// In "real life" this is poor programming practice
public class Sample {
	public static void main(String args[])
	     throws Exception
{
       // Create a parser factory
       SAXParserFactory factory = SAXParserFactory.newInstance();
       // Tell factory that the parser must understand namespaces
       factory.setNamespaceAware(true);
       // Make the parser
       SAXParser saxParser = factory.newSAXParser();
       XMLReader parser = saxParser.getXMLReader();
       // Create a handler
       Handler handler = new Handler();
       // Tell the parser to use this handler
       parser.setContentHandler(handler);
       // Finally, read and parse the document
       parser.parse("hello.xml");
    } // end of Sample class

}
package syntactic_analyzer;

import java.util.Scanner;
import java.util.Stack;

import javax.swing.Popup;

public class syntactic_analyzer {
	public static Stack<Integer>state = new Stack<Integer>();
	public static Stack<String>symbol = new Stack<String>();
	public static Stack<String> w = new Stack<String>();
	public static String[][] action= {
			{"S4","","","","","S5","",""},             //0
			{"","","S6","S7","","","","ACC"},          //1
			{"","","R3","R3","S8","S9","","R3"},       //2
			{"","","R6","R6","R6","R6","","R6"},       //3
			{"S13","","","","","","S14",""},           //4
			{"","","R8","R8","R8","R8","","R8"},       //5
			{"S4","","","","","","S5",""},             //6
			{"S4","","","","","","S5",""},             //7
			{"S4","","","","","","S5",""},             //8
			{"S4","","","","","","S5",""},             //9
			{"","S19","S20","S21","","","",""},        //10
			{"","R3","R3","R3","S22","S23","",""},     //11
			{"","R6","R6","R6","R6","R6","",""},       //12
			{"S13","","","","","","S14",""},           //13
			{"","R8","R8","R8","R8","R8","",""},       //14
			{"","","R1","R1","S8","S9","","R1"},       //15
			{"","","R2","R2","S8","S9","","R2"},       //16
			{"","","R4","R4","R4","R4","","R4"},       //17
			{"","","R5","R5","R5","R5","","R5"},       //18
			{"","","R7","R7","R7","R7","","R7"},       //19
			{"S13","","","","","","S14",""},           //20
			{"S13","","","","","","S14",""},           //21
			{"S13","","","","","","S14",""},           //22
			{"S13","","","","","","S14",""},           //23
			{"","S28","S20","S21","","","",""},        //24
			{"","R1","R1","R1","S22","S23","",""},     //25
			{"","R4","R4","R4","R4","R4","",""},       //26
			{"","R5","R5","R5","R5","R5","",""},       //27
			{"","R7","R7","R7","R7","R7","",""},       //28
			{"","R2","R2","R2","S22","S23","",""}};    //29
	public static int[][] go_to= {
			{1,2,3},       //0
			{-1,-1,-1},    //1
			{-1,-1,-1},    //2
			{-1,-1,-1},    //3
			{10,11,12},    //4
			{-1,-1,-1},    //5
			{-1,15,3},     //6
			{-1,16,3},     //7
			{-1,-1,17},    //8
			{-1,-1,18},    //9
			{-1,-1,-1},    //10
			{-1,-1,-1},    //11
			{-1,-1,-1},    //12
			{24,11,12},    //13
			{-1,-1,-1},    //14
			{-1,-1,-1},    //15
			{-1,-1,-1},    //16
			{-1,-1,-1},    //17
			{-1,-1,-1},    //18
			{-1,-1,-1},    //19
			{-1,25,12},    //20
			{-1,29,12},    //21
			{-1,-1,26},    //22
			{-1,-1,27},    //23
			{-1,-1,-1},    //24
			{-1,-1,-1},    //25
			{-1,-1,-1},    //26
			{-1,-1,-1},    //27
			{-1,-1,-1},    //28
			{-1,-1,-1}     //29
	};
	public static void reduce(String action_string) {
		//�ò���ʽE->E+T
		if(Integer.parseInt(action_string.substring(1))==1){
			//pop��3��Ԫ��
			state.pop();
			state.pop();
			state.pop();
			symbol.pop();
			symbol.pop();
			symbol.pop();
			//����ǰԪ��push��ȥ
			symbol.push("E");
			if(go_to[state.peek()][0]==-1) {
				System.out.println("��������");
				return;
			}
			state.push(go_to[state.peek()][0]);
		}
		//�ò���ʽE->E-T
		if(Integer.parseInt(action_string.substring(1))==2){
			//pop��3��Ԫ��
			state.pop();
			state.pop();
			state.pop();
			symbol.pop();
			symbol.pop();
			symbol.pop();
			//����ǰԪ��push��ȥ
			symbol.push("E");
			if(go_to[state.peek()][0]==-1) {
				System.out.println("��������");
				return;
			}
			state.push(go_to[state.peek()][0]);
		}
		//�ò���ʽE->T
		if(Integer.parseInt(action_string.substring(1))==3){
			//pop��1��Ԫ��
			state.pop();
			symbol.pop();
			//����ǰԪ��push��ȥ
			symbol.push("E");
			if(go_to[state.peek()][0]==-1) {
				System.out.println("��������");
				return;
			}
			state.push(go_to[state.peek()][0]);
		}
		//�ò���ʽT->T*F
		if(Integer.parseInt(action_string.substring(1))==4){
			//pop��3��Ԫ��
			state.pop();
			state.pop();
			state.pop();
			symbol.pop();
			symbol.pop();
			symbol.pop();
			//����ǰԪ��push��ȥ
			symbol.push("T");
			if(go_to[state.peek()][1]==-1) {
				System.out.println("��������");
				return;
			}
			state.push(go_to[state.peek()][1]);
		}
		//�ò���ʽT->T/F
		if(Integer.parseInt(action_string.substring(1))==5){
			//pop��3��Ԫ��
			state.pop();
			state.pop();
			state.pop();
			symbol.pop();
			symbol.pop();
			symbol.pop();
			//����ǰԪ��push��ȥ
			symbol.push("T");
			if(go_to[state.peek()][1]==-1) {
				System.out.println("��������");
				return;
			}
			state.push(go_to[state.peek()][1]);
		}
		//�ò���ʽT->F
		if(Integer.parseInt(action_string.substring(1))==6){
			//pop��1��Ԫ��
			state.pop();
			symbol.pop();
			//����ǰԪ��push��ȥ
			symbol.push("T");
			if(go_to[state.peek()][1]==-1) {
				System.out.println("��������");
				return;
			}
			state.push(go_to[state.peek()][1]);
		}
		//�ò���ʽF->(E)
		if(Integer.parseInt(action_string.substring(1))==7){
			//pop��3��Ԫ��
			state.pop();
			state.pop();
			state.pop();
			symbol.pop();
			symbol.pop();
			symbol.pop();
			//����ǰԪ��push��ȥ
			symbol.push("F");
			if(go_to[state.peek()][2]==-1) {
				System.out.println("��������");
				return;
			}
			state.push(go_to[state.peek()][2]);
		}
		//�ò���ʽF->num
		if(Integer.parseInt(action_string.substring(1))==8){
			//pop��1��Ԫ��
			state.pop();
			symbol.pop();
			//����ǰԪ��push��ȥ
			symbol.push("F");
			if(go_to[state.peek()][2]==-1) {
				System.out.println("��������");
				return;
			}
			state.push(go_to[state.peek()][2]);
		}
	}
	//���ز���ʽ
	public static String getExpression(int num) {
		String expression=new String();
		if(num==1)
			expression="E->E+T";
		else if(num==2)
			expression="E->E-T";
		else if(num==3)
			expression="E->T";
		else if(num==4)
			expression="T->T*F";
		else if(num==5)
			expression="T->T/F";
		else if(num==6)
			expression="T->F";
		else if(num==7)
			expression="F->(E)";
		else if(num==8)
			expression="F->num";
		return expression;
	}
	//��ӡaction
	public static void printAction(int step,String action_string) {
		String expressionString=new String();
		System.out.print(+step+"\t");
		System.out.printf("%-30s",state);
		System.out.printf("%-20s\t",symbol);
		for(int i =w.size()-1;i>=0;i--) {
			expressionString+=w.get(i);
		}
		System.out.printf("%25s",expressionString);
		System.out.println("\tshift "+Integer.parseInt(action_string.substring(1)));
	}
	//��ӡgoto
	public static void printgoto(int step,String action_string) {
		String expressionString=new String();
		System.out.print(+step+"\t");
		System.out.printf("%-30s",state);
		System.out.printf("%-20s\t",symbol);
		for(int i =w.size()-1;i>=0;i--) {
			expressionString+=w.get(i);
		}
		System.out.printf("%25s",expressionString);
		System.out.println("\treduce by "+getExpression(Integer.parseInt(action_string.substring(1))));
	}
	
	public static void main(String[] args) {
		Scanner scanner= new Scanner(System.in);
		System.out.print("������Ŵ��� ");
		String string = scanner.next();
		char[] chars = string.toCharArray();
		Stack<String> s = new Stack<String>();
		for(int i=0;i<chars.length;i++) {
			if(chars[i]!='n')
				s.push(String.valueOf(chars[i]));
			else {
				char[] temp=new char[3];
				temp[0]=chars[i];
				temp[1]=chars[i+1];
				temp[2]=chars[i+2];
				s.push(String.valueOf(temp));
				i=i+2;
			}
		}
		
		System.out.print("����\t\t״̬ջ\t\t\t  ����ջ\t\t\t\t���������\t\t��������\n");
		while (!s.empty())
			w.push(s.pop());
		state.push(0);
		symbol.push("$");
		int step=0;
		while (!w.empty()) {
			//ջ��״̬
			step++;
			int temp_state=state.peek();
			String action_string;
			String temp_s=w.peek();
			if(w.peek().equals("(")) {
				//������(��ʱ�Ķ���
				action_string=action[temp_state][0];
				if(action_string.equals("")) {
					System.out.println("��������");
					return;
				}
				//�ƽ�
				if(action_string.charAt(0)=='S') {
					printAction(step, action_string);
					state.push(Integer.parseInt(action_string.substring(1)));
					symbol.push(w.pop());	
				}
				//��Լ
				else if(action_string.charAt(0)=='R') {
					printgoto(step, action_string);
					reduce(action_string);
				}
			}
			else if(w.peek().equals(")")) {
				//������)��ʱ�Ķ���
				action_string=action[temp_state][1];
				if(action_string.equals("")) {
					System.out.println("��������");
					return;
				}
				//�ƽ�
				if(action_string.charAt(0)=='S') {
					printAction(step, action_string);
					state.push(Integer.parseInt(action_string.substring(1)));
					symbol.push(w.pop());	
				}
				//��Լ
				else if(action_string.charAt(0)=='R') {
					printgoto(step, action_string);
					reduce(action_string);
				}
			}
			else if(w.peek().equals("+")) {
				//������+��ʱ�Ķ���
				action_string=action[temp_state][2];
				if(action_string.equals("")) {
					System.out.println("��������");
					return;
				}
				//�ƽ�
				if(action_string.charAt(0)=='S') {
					printAction(step, action_string);
					state.push(Integer.parseInt(action_string.substring(1)));
					symbol.push(w.pop());					
				}
				//��Լ
				else if(action_string.charAt(0)=='R') {
					printgoto(step, action_string);
					reduce(action_string);
				}
			}
			else if(w.peek().equals("-")) {
				//������-��ʱ�Ķ���
				action_string=action[temp_state][3];
				if(action_string.equals("")) {
					System.out.println("��������");
					return;
				}
				//�ƽ�
				if(action_string.charAt(0)=='S') {
					printAction(step, action_string);
					state.push(Integer.parseInt(action_string.substring(1)));
					symbol.push(w.pop());					
				}
				//��Լ
				else if(action_string.charAt(0)=='R') {
					printgoto(step, action_string);
					reduce(action_string);
				}
			}
			else if(w.peek().equals("*")) {
				//������*��ʱ�Ķ���
				action_string=action[temp_state][4];
				if(action_string.equals("")) {
					System.out.println("��������");
					return;
				}
				//�ƽ�
				if(action_string.charAt(0)=='S') {
					printAction(step, action_string);
					state.push(Integer.parseInt(action_string.substring(1)));
					symbol.push(w.pop());					
				}
				//��Լ
				else if(action_string.charAt(0)=='R') {
					printgoto(step, action_string);
					reduce(action_string);
				}
			}
			else if(w.peek().equals("/")) {
				//������/��ʱ�Ķ���
				action_string=action[temp_state][5];
				if(action_string.equals("")) {
					System.out.println("��������");
					return;
				}
				//�ƽ�
				if(action_string.charAt(0)=='S') {
					printAction(step, action_string);
					state.push(Integer.parseInt(action_string.substring(1)));
					symbol.push(w.pop());					
				}
				//��Լ
				else if(action_string.charAt(0)=='R') {
					printgoto(step, action_string);
					reduce(action_string);
				}
			}
			else if(w.peek().equals("num")) {
				//������num��ʱ�Ķ���
				action_string=action[temp_state][6];
				if(action_string.equals("")){
					System.out.println("��������");
					return;
				}
				//�ƽ�
				if(action_string.charAt(0)=='S') {
					printAction(step, action_string);
					state.push(Integer.parseInt(action_string.substring(1)));
					symbol.push(w.pop());					
				}
				//��Լ
				else if(action_string.charAt(0)=='R') {
					printgoto(step, action_string);
					reduce(action_string);
				}
			}
			else if(w.peek().equals("$")) {
				//������$��ʱ�Ķ���
				action_string=action[temp_state][7];
				if(action_string.equals("")) {
					System.out.println("��������");
					return;
				}
				//���ܷ��Ŵ�
				if(action_string.equals("ACC")) {
					String expressionString=new String();
					System.out.print(+step+"\t");
					System.out.printf("%-30s",state);
					System.out.printf("%-20s\t",symbol);
					for(int i =w.size()-1;i>=0;i--) {
						expressionString+=w.get(i);
					}
					System.out.printf("%25s\t",expressionString);
					System.out.println("���ܳɹ�");
					state.pop();
					symbol.pop();		
					w.pop();
				}
				//�ƽ�
				if(action_string.charAt(0)=='S') {
					printAction(step, action_string);
					state.push(Integer.parseInt(action_string.substring(1)));
					symbol.push(w.pop());					
				}
				//��Լ
				else if(action_string.charAt(0)=='R') {
					printgoto(step, action_string);
					reduce(action_string);
				}
			}			
		}
	} 
}

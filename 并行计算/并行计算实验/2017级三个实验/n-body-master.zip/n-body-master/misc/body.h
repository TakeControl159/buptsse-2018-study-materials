
#ifndef _BODY_H_N_BODY_
#define _BODY_H_N_BODY_

typedef struct {
    double pos[3];
    double vel[3];
    double m;
    double work;
} Body;

#endif // _BODY_H_N_BODY_
